using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KertmesterAPI.Controllers
{
    public class KerttervTermekDTO
    {
        public int Kertterv_ID { get; set; }
        public int Termek_ID { get; set; }
    }

    // Kapcsolótábla (kertterv <-> termek), összetett kulccsal: (Kertterv_ID, Termek_ID).
    // Nincs Put, mert a sor minden oszlopa a kulcs része: módosítás = törlés + új felvétel.
    [Route("api/[controller]")]
    [ApiController]
    public class KerttervTermekController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public KerttervTermekController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/KerttervTermek
        [HttpGet]
        public IEnumerable<Kertterv_termek> Get()
        {
            return _ctx.Kertterv_Termek.Include(x => x.Kertterv)
                                       .Include(x => x.Termek);
        }

        // GET api/KerttervTermek/kertterv/1  -> egy kertterv összes terméke
        [HttpGet("kertterv/{kerttervId}")]
        public ActionResult<IEnumerable<Kertterv_termek>> GetByKertterv(int kerttervId)
        {
            if (!_ctx.Kertterv.Any(x => x.Id == kerttervId))
                return NotFound();
            var lista = _ctx.Kertterv_Termek.Include(x => x.Termek)
                                            .Where(x => x.Kertterv_ID == kerttervId)
                                            .ToList();
            return Ok(lista);
        }

        // GET api/KerttervTermek/1/11
        [HttpGet("{kerttervId}/{termekId}")]
        public ActionResult<Kertterv_termek> Get(int kerttervId, int termekId)
        {
            var kt = _ctx.Kertterv_Termek.Include(x => x.Kertterv)
                                         .Include(x => x.Termek)
                                         .FirstOrDefault(x => x.Kertterv_ID == kerttervId
                                                           && x.Termek_ID == termekId);
            if (kt == null)
                return NotFound();
            return Ok(kt);
        }

        // POST api/KerttervTermek
        [HttpPost]
        public ActionResult<Kertterv_termek> Post([FromBody] KerttervTermekDTO value)
        {
            if (!_ctx.Kertterv.Any(x => x.Id == value.Kertterv_ID))
                return BadRequest("A megadott kertterv nem létezik.");
            if (!_ctx.Termek.Any(x => x.Id == value.Termek_ID))
                return BadRequest("A megadott termék nem létezik.");
            if (_ctx.Kertterv_Termek.Any(x => x.Kertterv_ID == value.Kertterv_ID
                                           && x.Termek_ID == value.Termek_ID))
                return Conflict("Ez a termék már szerepel a kertterven.");

            var kt = new Kertterv_termek
            {
                Kertterv_ID = value.Kertterv_ID,
                Termek_ID = value.Termek_ID
            };
            _ctx.Kertterv_Termek.Add(kt);
            _ctx.SaveChanges();
            return StatusCode(201, kt);
        }

        // DELETE api/KerttervTermek/1/11
        [HttpDelete("{kerttervId}/{termekId}")]
        public ActionResult Delete(int kerttervId, int termekId)
        {
            var kt = _ctx.Kertterv_Termek.Find(kerttervId, termekId);
            if (kt == null)
                return NotFound();
            _ctx.Kertterv_Termek.Remove(kt);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
