using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KertmesterAPI.Controllers
{
    public class TermekDTO
    {
        public string? Nev { get; set; }
        public string? Leiras { get; set; }
        public double Ar { get; set; }
        public int Keszleten_Levo_Mennyiseg { get; set; }
        public string? Meret_Adatok { get; set; }
        public int Kategoria_ID { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class TermekController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public TermekController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/Termek
        [HttpGet]
        public IEnumerable<Termek> Get()
        {
            return _ctx.Termek.Include(x => x.Kategoria);
        }

        // GET api/Termek/5
        [HttpGet("{id}")]
        public ActionResult<Termek> Get(int id)
        {
            var termek = _ctx.Termek.Include(x => x.Kategoria)
                                    .FirstOrDefault(x => x.Id == id);
            if (termek == null)
                return NotFound();
            return Ok(termek);
        }

        // POST api/Termek
        [HttpPost]
        public ActionResult<Termek> Post([FromBody] TermekDTO value)
        {
            if (!_ctx.Kategoria.Any(x => x.Id == value.Kategoria_ID))
                return BadRequest("A megadott kategória nem létezik.");

            var termek = new Termek
            {
                Nev = value.Nev,
                Leiras = value.Leiras,
                Ar = value.Ar,
                Keszleten_Levo_Mennyiseg = value.Keszleten_Levo_Mennyiseg,
                Meret_Adatok = value.Meret_Adatok,
                Kategoria_ID = value.Kategoria_ID
            };
            _ctx.Termek.Add(termek);
            _ctx.SaveChanges();
            return StatusCode(201, termek);
        }

        // PUT api/Termek/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] TermekDTO value)
        {
            var termek = _ctx.Termek.Find(id);
            if (termek == null)
                return NotFound();
            if (!_ctx.Kategoria.Any(x => x.Id == value.Kategoria_ID))
                return BadRequest("A megadott kategória nem létezik.");

            termek.Nev = value.Nev;
            termek.Leiras = value.Leiras;
            termek.Ar = value.Ar;
            termek.Keszleten_Levo_Mennyiseg = value.Keszleten_Levo_Mennyiseg;
            termek.Meret_Adatok = value.Meret_Adatok;
            termek.Kategoria_ID = value.Kategoria_ID;
            _ctx.SaveChanges();
            return NoContent();
        }

        // DELETE api/Termek/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var termek = _ctx.Termek.Find(id);
            if (termek == null)
                return NotFound();
            _ctx.Termek.Remove(termek);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
