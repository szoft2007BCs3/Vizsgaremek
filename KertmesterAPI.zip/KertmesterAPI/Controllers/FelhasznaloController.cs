using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace KertmesterAPI.Controllers
{
    public class FelhasznaloDTO
    {
        public string? Nev { get; set; }
        public string? Email { get; set; }
        public string? Jelszo { get; set; }
        public string? Telefonszam { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class FelhasznaloController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public FelhasznaloController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/Felhasznalo
        [HttpGet]
        public IEnumerable<Felhasznalo> Get()
        {
            return _ctx.Felhasznalo;
        }

        // GET api/Felhasznalo/5
        [HttpGet("{id}")]
        public ActionResult<Felhasznalo> Get(int id)
        {
            var felhasznalo = _ctx.Felhasznalo.Find(id);
            if (felhasznalo == null)
                return NotFound();
            return Ok(felhasznalo);
        }

        // POST api/Felhasznalo
        [HttpPost]
        public ActionResult<Felhasznalo> Post([FromBody] FelhasznaloDTO value)
        {
            // Az Email egyedi az adatbázisban
            if (_ctx.Felhasznalo.Any(x => x.Email == value.Email))
                return Conflict("Ezzel az email címmel már van regisztrált felhasználó.");

            var felhasznalo = new Felhasznalo
            {
                Nev = value.Nev,
                Email = value.Email,
                Jelszo = value.Jelszo,
                Telefonszam = value.Telefonszam,
                Regisztracio_Datuma = DateTime.Now
            };
            _ctx.Felhasznalo.Add(felhasznalo);
            _ctx.SaveChanges();
            return StatusCode(201, felhasznalo);
        }

        // PUT api/Felhasznalo/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] FelhasznaloDTO value)
        {
            var felhasznalo = _ctx.Felhasznalo.Find(id);
            if (felhasznalo == null)
                return NotFound();
            if (_ctx.Felhasznalo.Any(x => x.Email == value.Email && x.Id != id))
                return Conflict("Ezzel az email címmel már van regisztrált felhasználó.");

            felhasznalo.Nev = value.Nev;
            felhasznalo.Email = value.Email;
            felhasznalo.Jelszo = value.Jelszo;
            felhasznalo.Telefonszam = value.Telefonszam;
            _ctx.SaveChanges();
            return NoContent();
        }

        // DELETE api/Felhasznalo/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var felhasznalo = _ctx.Felhasznalo.Find(id);
            if (felhasznalo == null)
                return NotFound();
            _ctx.Felhasznalo.Remove(felhasznalo);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
