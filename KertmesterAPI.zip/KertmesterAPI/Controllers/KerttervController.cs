using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KertmesterAPI.Controllers
{
    public class KerttervDTO
    {
        public string? Nev { get; set; }
        public string? Kertterv_kep { get; set; }
        public double Kert_Hosszusaga { get; set; }
        public double Kert_Szelessege { get; set; }
        public int Felhasznalo_ID { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class KerttervController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public KerttervController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/Kertterv
        [HttpGet]
        public IEnumerable<Kertterv> Get()
        {
            return _ctx.Kertterv.Include(x => x.Felhasznalo);
        }

        // GET api/Kertterv/5
        [HttpGet("{id}")]
        public ActionResult<Kertterv> Get(int id)
        {
            var kertterv = _ctx.Kertterv.Include(x => x.Felhasznalo)
                                        .FirstOrDefault(x => x.Id == id);
            if (kertterv == null)
                return NotFound();
            return Ok(kertterv);
        }

        // POST api/Kertterv
        [HttpPost]
        public ActionResult<Kertterv> Post([FromBody] KerttervDTO value)
        {
            if (!_ctx.Felhasznalo.Any(x => x.Id == value.Felhasznalo_ID))
                return BadRequest("A megadott felhasználó nem létezik.");

            var kertterv = new Kertterv
            {
                Nev = value.Nev,
                Kertterv_kep = value.Kertterv_kep,
                Kert_Hosszusaga = value.Kert_Hosszusaga,
                Kert_Szelessege = value.Kert_Szelessege,
                Felhasznalo_ID = value.Felhasznalo_ID,
                Letrehozas_Datuma = DateTime.Now,
                Utolso_Modosítás = DateTime.Now
            };
            _ctx.Kertterv.Add(kertterv);
            _ctx.SaveChanges();
            return StatusCode(201, kertterv);
        }

        // PUT api/Kertterv/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] KerttervDTO value)
        {
            var kertterv = _ctx.Kertterv.Find(id);
            if (kertterv == null)
                return NotFound();
            if (!_ctx.Felhasznalo.Any(x => x.Id == value.Felhasznalo_ID))
                return BadRequest("A megadott felhasználó nem létezik.");

            kertterv.Nev = value.Nev;
            kertterv.Kertterv_kep = value.Kertterv_kep;
            kertterv.Kert_Hosszusaga = value.Kert_Hosszusaga;
            kertterv.Kert_Szelessege = value.Kert_Szelessege;
            kertterv.Felhasznalo_ID = value.Felhasznalo_ID;
            kertterv.Utolso_Modosítás = DateTime.Now;
            _ctx.SaveChanges();
            return NoContent();
        }

        // DELETE api/Kertterv/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var kertterv = _ctx.Kertterv.Find(id);
            if (kertterv == null)
                return NotFound();
            _ctx.Kertterv.Remove(kertterv);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
