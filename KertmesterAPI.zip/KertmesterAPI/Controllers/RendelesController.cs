using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KertmesterAPI.Controllers
{
    public class RendelesDTO
    {
        public string? Szallitasi_Cim { get; set; }
        public string? Statusz { get; set; }
        public double Vegosszeg { get; set; }
        public int Kertterv_ID { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class RendelesController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public RendelesController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/Rendeles
        [HttpGet]
        public IEnumerable<Rendeles> Get()
        {
            return _ctx.Rendeles.Include(x => x.Kertterv);
        }

        // GET api/Rendeles/5
        [HttpGet("{id}")]
        public ActionResult<Rendeles> Get(int id)
        {
            var rendeles = _ctx.Rendeles.Include(x => x.Kertterv)
                                        .FirstOrDefault(x => x.Id == id);
            if (rendeles == null)
                return NotFound();
            return Ok(rendeles);
        }

        // POST api/Rendeles
        [HttpPost]
        public ActionResult<Rendeles> Post([FromBody] RendelesDTO value)
        {
            if (!_ctx.Kertterv.Any(x => x.Id == value.Kertterv_ID))
                return BadRequest("A megadott kertterv nem létezik.");

            var rendeles = new Rendeles
            {
                Szallitasi_Cim = value.Szallitasi_Cim,
                Statusz = value.Statusz,
                Vegosszeg = value.Vegosszeg,
                Kertterv_ID = value.Kertterv_ID,
                Rendeles_Datuma = DateTime.Now
            };
            _ctx.Rendeles.Add(rendeles);
            _ctx.SaveChanges();
            return StatusCode(201, rendeles);
        }

        // PUT api/Rendeles/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] RendelesDTO value)
        {
            var rendeles = _ctx.Rendeles.Find(id);
            if (rendeles == null)
                return NotFound();
            if (!_ctx.Kertterv.Any(x => x.Id == value.Kertterv_ID))
                return BadRequest("A megadott kertterv nem létezik.");

            rendeles.Szallitasi_Cim = value.Szallitasi_Cim;
            rendeles.Statusz = value.Statusz;
            rendeles.Vegosszeg = value.Vegosszeg;
            rendeles.Kertterv_ID = value.Kertterv_ID;
            _ctx.SaveChanges();
            return NoContent();
        }

        // DELETE api/Rendeles/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var rendeles = _ctx.Rendeles.Find(id);
            if (rendeles == null)
                return NotFound();
            _ctx.Rendeles.Remove(rendeles);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
