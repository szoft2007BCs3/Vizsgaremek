using KertmesterAPI.Database;
using KertmesterAPI.Models;
using Microsoft.AspNetCore.Mvc;

namespace KertmesterAPI.Controllers
{
    public class KategoriaDTO
    {
        public string? Nev { get; set; }
        public string? Leiras { get; set; }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class KategoriaController : ControllerBase
    {
        private readonly KertmesterContext _ctx;
        public KategoriaController(KertmesterContext ctx)
        {
            _ctx = ctx;
        }

        // GET: api/Kategoria
        [HttpGet]
        public IEnumerable<Kategoria> Get()
        {
            return _ctx.Kategoria;
        }

        // GET api/Kategoria/5
        [HttpGet("{id}")]
        public ActionResult<Kategoria> Get(int id)
        {
            var kategoria = _ctx.Kategoria.Find(id);
            if (kategoria == null)
                return NotFound();
            return Ok(kategoria);
        }

        // POST api/Kategoria
        [HttpPost]
        public ActionResult<Kategoria> Post([FromBody] KategoriaDTO value)
        {
            var kategoria = new Kategoria
            {
                Nev = value.Nev,
                Leiras = value.Leiras
            };
            _ctx.Kategoria.Add(kategoria);
            _ctx.SaveChanges();
            return StatusCode(201, kategoria);
        }

        // PUT api/Kategoria/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] KategoriaDTO value)
        {
            var kategoria = _ctx.Kategoria.Find(id);
            if (kategoria == null)
                return NotFound();
            kategoria.Nev = value.Nev;
            kategoria.Leiras = value.Leiras;
            _ctx.SaveChanges();
            return NoContent();
        }

        // DELETE api/Kategoria/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var kategoria = _ctx.Kategoria.Find(id);
            if (kategoria == null)
                return NotFound();
            _ctx.Kategoria.Remove(kategoria);
            _ctx.SaveChanges();
            return NoContent();
        }
    }
}
