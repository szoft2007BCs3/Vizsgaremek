using KertmesterAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace KertmesterAPI.Database
{
    public class KertmesterContext : DbContext
    {
        public DbSet<Felhasznalo> Felhasznalo { get; set; }
        public DbSet<Kategoria> Kategoria { get; set; }
        public DbSet<Kertterv> Kertterv { get; set; }
        public DbSet<Kertterv_termek> Kertterv_Termek { get; set; }
        public DbSet<Rendeles> Rendeles { get; set; }
        public DbSet<Termek> Termek { get; set; }

        public KertmesterContext(DbContextOptions<KertmesterContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Táblanevek az SQL szerint (kisbetűs)
            modelBuilder.Entity<Felhasznalo>().ToTable("felhasznalo");
            modelBuilder.Entity<Kategoria>().ToTable("kategoria");
            modelBuilder.Entity<Kertterv>().ToTable("kertterv");
            modelBuilder.Entity<Kertterv_termek>().ToTable("kertterv_termek");
            modelBuilder.Entity<Rendeles>().ToTable("rendeles");
            modelBuilder.Entity<Termek>().ToTable("termek");

            // Összetett elsődleges kulcs a kapcsolótáblán
            modelBuilder.Entity<Kertterv_termek>()
                .HasKey(x => new { x.Kertterv_ID, x.Termek_ID });

            // Oszlopnevek, ahol a modell tulajdonságneve eltér az adatbázistól
            modelBuilder.Entity<Kertterv>().Property(x => x.Kert_Hosszusaga).HasColumnName("Kert_Hosszusag");
            modelBuilder.Entity<Kertterv>().Property(x => x.Kert_Szelessege).HasColumnName("Kert_Szelesseg");
            modelBuilder.Entity<Kertterv>().Property(x => x.Utolso_Modosítás).HasColumnName("Utolso_Modositas");

            // Idegen kulcsok (a Xxx_ID elnevezést az EF nem találja ki magától)
            modelBuilder.Entity<Kertterv>()
                .HasOne(x => x.Felhasznalo).WithMany().HasForeignKey(x => x.Felhasznalo_ID);
            modelBuilder.Entity<Kertterv_termek>()
                .HasOne(x => x.Kertterv).WithMany().HasForeignKey(x => x.Kertterv_ID);
            modelBuilder.Entity<Kertterv_termek>()
                .HasOne(x => x.Termek).WithMany().HasForeignKey(x => x.Termek_ID);
            modelBuilder.Entity<Rendeles>()
                .HasOne(x => x.Kertterv).WithMany().HasForeignKey(x => x.Kertterv_ID);
            modelBuilder.Entity<Termek>()
                .HasOne(x => x.Kategoria).WithMany().HasForeignKey(x => x.Kategoria_ID);
        }
    }
}
